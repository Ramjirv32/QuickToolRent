<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/header.php';

$pdo = db();

// Simple search by name/description
$q = trim($_GET['q'] ?? '');
$sql = "SELECT p.*, u.name AS owner_name 
        FROM products p 
        JOIN users u ON u.id = p.owner_id
        WHERE p.status = 'available'";

$params = [];
if ($q !== '') {
  $sql .= " AND (p.name LIKE :q OR p.description LIKE :q)";
  $params[':q'] = '%' . $q . '%';
}
$sql .= " ORDER BY p.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
?>
<section class="mb-8">
  <h1 class="text-2xl font-semibold text-pretty">Find tools fast</h1>
  <p class="text-gray-600">Borrow what you need. Owners earn from unused tools. Delivery in 30–60 minutes.</p>
  <form method="get" class="mt-4 flex items-center gap-2">
    <input
      type="text"
      name="q"
      value="<?php echo htmlspecialchars($q); ?>"
      placeholder="Search drills, saws, ladders..."
      class="w-full md:w-1/2 rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
    />
    <button class="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">Search</button>
  </form>
</section>

<section>
  <?php if (empty($products)): ?>
    <div class="rounded border border-gray-200 bg-white p-6 text-center text-gray-600">No products found.</div>
  <?php else: ?>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
      <?php foreach ($products as $p): ?>
        <article class="rounded border border-gray-200 bg-white overflow-hidden">
          <div class="h-40 bg-gray-100 flex items-center justify-center">
            <span class="text-gray-400 text-sm">Image</span>
          </div>
          <div class="p-4">
            <h3 class="font-semibold"><?php echo htmlspecialchars($p['name']); ?></h3>
            <p class="text-sm text-gray-600 mt-1 line-clamp-2"><?php echo htmlspecialchars($p['description']); ?></p>
            <p class="mt-2 text-sm text-gray-700">
              By <span class="font-medium"><?php echo htmlspecialchars($p['owner_name']); ?></span>
            </p>
            <div class="mt-3 flex items-center justify-between">
              <div class="text-sm">
                <span class="font-semibold text-blue-700">$<?php echo number_format((float)$p['price_per_hour'], 2); ?></span>
                <span class="text-gray-500">/hour</span>
                <span class="mx-2 text-gray-300">•</span>
                <span class="font-semibold text-blue-700">$<?php echo number_format((float)$p['price_per_day'], 2); ?></span>
                <span class="text-gray-500">/day</span>
              </div>
              <a href="/rent-product.php?id=<?php echo (int)$p['id']; ?>"
                 class="rounded bg-blue-600 px-3 py-2 text-white text-sm hover:bg-blue-700">
                Rent
              </a>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
