<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

require_login();
$stmt = db()->prepare("SELECT r.*, p.name, p.image_url FROM rentals r JOIN products p ON p.id = r.product_id WHERE r.borrower_id = ? ORDER BY r.created_at DESC");
$stmt->execute([$_SESSION['user']['id']]);
$rentals = $stmt->fetchAll();
?>
<section class="max-w-6xl mx-auto px-4 py-10">
  <h1 class="text-2xl font-semibold mb-6">My Rentals</h1>
  <div class="grid gap-6 sm:grid-cols-2 md:grid-cols-3">
    <?php foreach ($rentals as $r): ?>
      <div class="border border-gray-200 rounded-lg overflow-hidden">
        <div class="aspect-video bg-gray-100 flex items-center justify-center">
          <span class="text-gray-400 text-sm">Image</span>
        </div>
        <div class="p-4">
          <div class="font-medium"><?= e($r['name']) ?></div>
          <div class="text-sm text-gray-600 mt-1">Total: <?= money((float)$r['total_amount']) ?></div>
          <div class="text-xs mt-2">Status: <span class="font-medium"><?= e($r['status']) ?></span></div>
          <div class="text-xs text-gray-600">Delivery ETA: <?= (int)$r['delivery_eta_minutes'] ?> min</div>
        </div>
      </div>
    <?php endforeach; ?>
    <?php if (empty($rentals)): ?>
      <p class="text-gray-600">No rentals yet. Find your first tool!</p>
    <?php endif; ?>
  </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
