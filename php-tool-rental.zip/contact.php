<?php require_once __DIR__ . '/includes/header.php'; ?>
<section class="max-w-3xl mx-auto px-4 py-12">
  <h1 class="text-2xl font-semibold">Contact</h1>
  <p class="text-gray-700 mt-3">Questions? Email <a class="text-blue-600 hover:underline" href="mailto:support@example.com">support@example.com</a></p>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
