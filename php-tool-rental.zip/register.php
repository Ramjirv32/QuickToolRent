<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/helpers.php';
$err = ''; $ok = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_validate()) {
  $name = trim($_POST['name'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $phone = trim($_POST['phone'] ?? '');
  $pass = $_POST['password'] ?? '';
  $role = ($_POST['role'] ?? 'borrower') === 'owner' ? 'owner' : 'borrower';
  if ($name && $email && $pass) {
    try {
      $stmt = db()->prepare("INSERT INTO users (name,email,phone,password_hash,role) VALUES (?,?,?,?,?)");
      $stmt->execute([$name, $email, $phone, password_hash($pass, PASSWORD_BCRYPT), $role]);
      $ok = 'Account created. You can log in now.';
    } catch (Exception $e) {
      $err = 'Unable to register. Email may be in use.';
    }
  } else {
    $err = 'Please fill all required fields.';
  }
}
?>
<section class="max-w-md mx-auto px-4 py-12">
  <h1 class="text-2xl font-semibold mb-6">Sign Up</h1>
  <?php if ($err): ?><div class="mb-4 text-sm text-red-600"><?= e($err) ?></div><?php endif; ?>
  <?php if ($ok): ?><div class="mb-4 text-sm text-green-700"><?= e($ok) ?></div><?php endif; ?>
  <form method="post" class="grid gap-4 border border-gray-200 rounded-lg p-4">
    <?= csrf_input(); ?>
    <label class="grid gap-1">
      <span class="text-sm font-medium">Full Name</span>
      <input required type="text" name="name" class="border border-gray-300 rounded-md px-3 py-2">
    </label>
    <label class="grid gap-1">
      <span class="text-sm font-medium">Email</span>
      <input required type="email" name="email" class="border border-gray-300 rounded-md px-3 py-2">
    </label>
    <label class="grid gap-1">
      <span class="text-sm font-medium">Phone</span>
      <input type="text" name="phone" class="border border-gray-300 rounded-md px-3 py-2">
    </label>
    <label class="grid gap-1">
      <span class="text-sm font-medium">Password</span>
      <input required type="password" name="password" class="border border-gray-300 rounded-md px-3 py-2">
    </label>
    <label class="grid gap-1">
      <span class="text-sm font-medium">I am a</span>
      <select name="role" class="border border-gray-300 rounded-md px-3 py-2">
        <option value="borrower">Borrower</option>
        <option value="owner">Owner</option>
      </select>
    </label>
    <button class="inline-flex items-center justify-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md">Create Account</button>
  </form>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
