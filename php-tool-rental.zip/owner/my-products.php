<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_login();
if (!is_owner()) { header('Location: ' . (BASE_URL ?: '/') . 'index.php'); exit; }

if (isset($_GET['toggle'])) {
  $pid = (int)$_GET['toggle'];
  $stmt = db()->prepare("UPDATE products SET status = IF(status='available','unavailable','available') WHERE id = ? AND owner_id = ?");
  $stmt->execute([$pid, $_SESSION['user']['id']]);
  header('Location: ' . (BASE_URL ?: '/') . 'owner/my-products.php'); exit;
}
$stmt = db()->prepare("SELECT * FROM products WHERE owner_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['user']['id']]);
$products = $stmt->fetchAll();
?>
<section class="max-w-6xl mx-auto px-4 py-10">
  <div class="flex items-center justify-between">
    <h1 class="text-2xl font-semibold">My Products</h1>
    <a href="<?= BASE_URL ?: '/' ?>owner/add-product.php" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md">Add Product</a>
  </div>
  <div class="grid gap-6 sm:grid-cols-2 md:grid-cols-3 mt-6">
    <?php foreach ($products as $p): ?>
      <div class="border border-gray-200 rounded-lg overflow-hidden">
        <div class="aspect-video bg-gray-100 flex items-center justify-center">
          <span class="text-gray-400 text-sm">Image</span>
        </div>
        <div class="p-4">
          <div class="font-medium"><?= e($p['name']) ?></div>
          <div class="text-sm text-gray-600 mt-1"><?= money((float)$p['price_per_hour']) ?>/hour</div>
          <div class="mt-3 flex items-center justify-between">
            <span class="text-xs <?= $p['status'] === 'available' ? 'text-emerald-700' : 'text-gray-600' ?>">
              <?= $p['status'] === 'available' ? 'Available' : 'Unavailable' ?>
            </span>
            <a class="text-blue-600 hover:underline" href="<?= BASE_URL ?: '/' ?>owner/my-products.php?toggle=<?= (int)$p['id'] ?>">Toggle</a>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
    <?php if (empty($products)): ?>
      <p class="text-gray-600">No products yet. Add your first one!</p>
    <?php endif; ?>
  </div>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
