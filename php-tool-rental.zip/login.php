<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/auth.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_validate()) {
  $email = trim($_POST['email'] ?? '');
  $pass = $_POST['password'] ?? '';
  if ($email && $pass && login_user($email, $pass)) {
    header('Location: ' . (BASE_URL ?: '/') . 'index.php'); exit;
  } else {
    $err = 'Invalid email or password.';
  }
}
?>
<section class="max-w-md mx-auto px-4 py-12">
  <h1 class="text-2xl font-semibold mb-6">Login</h1>
  <?php if ($err): ?><div class="mb-4 text-sm text-red-600"><?= e($err) ?></div><?php endif; ?>
  <form method="post" class="grid gap-4 border border-gray-200 rounded-lg p-4">
    <?= csrf_input(); ?>
    <label class="grid gap-1">
      <span class="text-sm font-medium">Email</span>
      <input required type="email" name="email" class="border border-gray-300 rounded-md px-3 py-2">
    </label>
    <label class="grid gap-1">
      <span class="text-sm font-medium">Password</span>
      <input required type="password" name="password" class="border border-gray-300 rounded-md px-3 py-2">
    </label>
    <button class="inline-flex items-center justify-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md">Login</button>
  </form>
  <p class="text-sm text-gray-600 mt-3">No account? <a class="text-blue-600 hover:underline" href="<?= BASE_URL ?: '/' ?>register.php">Sign up</a></p>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
