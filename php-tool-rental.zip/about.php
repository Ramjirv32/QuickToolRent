<?php require_once __DIR__ . '/includes/header.php'; ?>
<section class="max-w-4xl mx-auto px-4 py-12">
  <h1 class="text-2xl font-semibold">How It Works</h1>
  <div class="mt-4 space-y-4 text-gray-700">
    <p>We connect owners who have tools with borrowers who need them—fast.</p>
    <ul class="list-disc pl-6">
      <li><span class="font-medium">Owners:</span> Upload tools, set fair prices (within limits), and earn from unused gear.</li>
      <li><span class="font-medium">Borrowers:</span> Browse tools, pay securely via multiple options, get delivery in 30–60 minutes.</li>
    </ul>
    <p>Promoting resource sharing and a community-driven economy where everyone benefits.</p>
  </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
