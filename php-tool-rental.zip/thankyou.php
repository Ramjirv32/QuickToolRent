<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

$rid = (int)($_GET['rid'] ?? 0);
$uid = $_SESSION['user']['id'] ?? 0;
$stmt = db()->prepare("SELECT r.*, p.name FROM rentals r JOIN products p ON p.id = r.product_id WHERE r.id = ? AND r.borrower_id = ? LIMIT 1");
$stmt->execute([$rid, $uid]);
$rental = $stmt->fetch();
?>
<section class="max-w-3xl mx-auto px-4 py-16 text-center">
  <?php if ($rental): ?>
    <h1 class="text-3xl font-bold">Thank you! Your rental is confirmed.</h1>
    <p class="text-gray-700 mt-4">“<?= e($rental['name']) ?>” will be delivered in approximately <span class="font-medium"><?= (int)$rental['delivery_eta_minutes'] ?></span> minutes.</p>
    <p class="text-gray-600 mt-2">Order Total: <span class="font-medium"><?= money((float)$rental['total_amount']) ?></span></p>
    <a href="<?= BASE_URL ?: '/' ?>my-rentals.php" class="inline-flex items-center px-4 py-2 mt-6 bg-blue-600 hover:bg-blue-700 text-white rounded-md">View My Rentals</a>
  <?php else: ?>
    <h1 class="text-2xl font-semibold">Order not found</h1>
    <a href="<?= BASE_URL ?: '/' ?>index.php" class="inline-flex items-center px-4 py-2 mt-6 border border-gray-300 rounded-md">Back to Browse</a>
  <?php endif; ?>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
