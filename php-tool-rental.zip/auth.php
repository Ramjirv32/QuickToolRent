<?php require_once __DIR__.'/includes/header.php'; ?>
<?php // Redirector page (optional) ?>
<section class="max-w-3xl mx-auto px-4 py-10">
  <h1 class="text-2xl font-semibold">Authentication</h1>
  <p class="text-slate-600 mt-2">Use the navigation to Login or Sign Up.</p>
</section>
<?php require_once __DIR__.'/includes/footer.php'; ?>
