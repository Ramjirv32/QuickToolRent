<?php
// Rename these values to match your MySQL setup.
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'tool_rental');
define('DB_USER', 'root');
define('DB_PASS', 'password');

// Fair price limits (example limits — adjust as needed)
define('MAX_PRICE_PER_HOUR', 50.00);
define('MAX_PRICE_PER_DAY', 250.00);

// Basic app metadata
define('APP_NAME', 'QuickToolRent');
define('APP_TAGLINE', 'Rent tools fast. Delivered in 30–60 minutes.');

define('BASE_URL', ''); // e.g. 'http://localhost' or leave empty for root-relative links

define('MIN_PRICE_PER_HOUR', 1.00);
define('MIN_PRICE_PER_DAY', 5.00);

// Keep existing constants
