<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
  session_start();
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title><?php echo APP_NAME; ?></title>
    <meta name="description" content="<?php echo APP_TAGLINE; ?>">
    <script src="https://cdn.tailwindcss.com"></script>
  </head>
  <body class="bg-gray-50 text-gray-900">
    <header class="bg-white border-b">
      <nav class="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        <a href="<?= BASE_URL ?: '/' ?>index.php" class="text-xl font-semibold text-blue-600">
          <?php echo APP_NAME; ?>
        </a>
        <ul class="flex items-center gap-4">
          <li><a class="text-gray-700 hover:text-blue-600" href="<?= BASE_URL ?: '/' ?>index.php">Browse</a></li>
          <li><a class="text-gray-700 hover:text-blue-600" href="<?= BASE_URL ?: '/' ?>about.php">How it works</a></li>
          <li><a class="text-gray-700 hover:text-blue-600" href="<?= BASE_URL ?: '/' ?>contact.php">Contact</a></li>
          <li><a class="text-gray-700 hover:text-blue-600" href="<?= BASE_URL ?: '/' ?>my-rentals.php">My Rentals</a></li>
          <li><a class="text-gray-700 hover:text-blue-600" href="<?= BASE_URL ?: '/' ?>owner/my-products.php">Owner</a></li>
          <?php if (!empty($_SESSION['user']) && ($_SESSION['user']['role'] ?? '') === 'admin'): ?>
            <li><a class="text-blue-600 font-medium" href="<?= BASE_URL ?: '/' ?>admin/index.php">Admin</a></li>
          <?php endif; ?>
          <?php if (!empty($_SESSION['user'])): ?>
            <li class="text-gray-600">Hi, <?= htmlspecialchars($_SESSION['user']['name'] ?? 'User') ?></li>
            <li><a class="text-gray-700 hover:text-blue-600" href="<?= BASE_URL ?: '/' ?>logout.php">Logout</a></li>
          <?php else: ?>
            <li><a class="text-gray-700 hover:text-blue-600" href="<?= BASE_URL ?: '/' ?>login.php">Login</a></li>
            <li><a class="text-gray-700 hover:text-blue-600" href="<?= BASE_URL ?: '/' ?>register.php">Sign up</a></li>
          <?php endif; ?>
        </ul>
      </nav>
    </header>
    <main class="max-w-6xl mx-auto px-4 py-6">
      <?php if (!empty($_SESSION['flash_success'])): ?>
        <div class="mb-4 rounded border border-green-200 bg-green-50 text-green-800 px-4 py-3">
          <?php echo htmlspecialchars($_SESSION['flash_success']); unset($_SESSION['flash_success']); ?>
        </div>
      <?php endif; ?>
      <?php if (!empty($_SESSION['flash_error'])): ?>
        <div class="mb-4 rounded border border-red-200 bg-red-50 text-red-800 px-4 py-3">
          <?php echo htmlspecialchars($_SESSION['flash_error']); unset($_SESSION['flash_error']); ?>
        </div>
      <?php endif; ?>
