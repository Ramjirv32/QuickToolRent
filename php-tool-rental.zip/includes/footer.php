</main>
    <footer class="border-t bg-white">
      <div class="max-w-6xl mx-auto px-4 py-6 text-sm text-gray-600">
        <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?> — <?php echo APP_TAGLINE; ?></p>
        <p class="mt-1">Community-driven, fast delivery (30–60 minutes), and fair pricing.</p>
        <div class="mt-3 flex flex-wrap gap-4 text-sm">
          <a class="hover:text-blue-600" href="<?= BASE_URL ?: '/' ?>about.php">About</a>
          <a class="hover:text-blue-600" href="<?= BASE_URL ?: '/' ?>terms.php">Terms</a>
          <a class="hover:text-blue-600" href="<?= BASE_URL ?: '/' ?>privacy.php">Privacy</a>
          <a class="hover:text-blue-600" href="<?= BASE_URL ?: '/' ?>contact.php">Contact</a>
        </div>
      </div>
    </footer>
  </body>
</html>
